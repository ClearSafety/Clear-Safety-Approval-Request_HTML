import flet as ft
from time import sleep
import os
import json
from module_create_dropdown import create_Dropdown
from module_create_textfield import create_Textfield
from module_create_pricebreakdown import create_PriceBreakdownGroup
from module_create_uplift import create_UpliftGroup

os.getenv('FLET_SECRET_KEY')


###############################################################################################################################################################################################
# DATA FROM AIRTABLE
###############################################################################################################################################################################################
# TENURE LIST
try:
    tenure_list = [
        {'Tenure Types': 'Simplicity'},
        {'Tenure Types': 'PRH - General Needs'},
        {'Tenure Types': 'Pathways'},
        {'Tenure Types': 'Market Rent'}
    ]
except:
    tenure_list = []
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


# SOR CODE LIST
try:
    sor_code_list = [
        {'SOR Code': 'NHGETC001', 'SOR Description': '3 star PPM with all IOT  SASS fee and equipment charge included (vericon BCM x1 Micro dot autofill 2 switch live from controls  to be wired into BSM ) (order C)', 'SOR Cost (BSW)': 280},
        {'SOR Code': 'NHGETC002', 'SOR Description': '1 star with all IOT  SASS fee and equipment charge included (vericon BCM x1 Micro dot autofill 2 switch live from controls  to be wired into BSM ) (order E)', 'SOR Cost (BSW)': 163}
    ]
    sor_code_list_price = [
        {'SOR Code': 'NHGETC001', 'SOR Description': '3 star PPM with all IOT  SASS fee and equipment charge included (vericon BCM x1 Micro dot autofill 2 switch live from controls  to be wired into BSM ) (order C)', 'SOR Cost (BSW)': 280},
        {'SOR Code': 'NHGETC002', 'SOR Description': '1 star with all IOT  SASS fee and equipment charge included (vericon BCM x1 Micro dot autofill 2 switch live from controls  to be wired into BSM ) (order E)', 'SOR Cost (BSW)': 163}
    ]
    sor_code_list_uplift = [
        {'SOR Code': 'NHGETC100', 'SOR Description': r'% uplift to out of scope materials ', 'Uplift BSW': 0.25},
        {'SOR Code': 'NHGETC101', 'SOR Description': r'% uplift to plant hire out of scope ', 'Uplift BSW': 0.1}
    ]

except:
    sor_code_list = []
    sor_code_list_price = []
    sor_code_list_uplift = []  
#----------------------------------------------------------------------------
###############################################################################################################################################################################################




###############################################################################################################################################################################################
# GENERAL FUNCIONS
###############################################################################################################################################################################################
def check_file(folder, filename):
    path = os.path.join(folder, filename)
    return os.path.isfile(path)
###############################################################################################################################################################################################




###############################################################################################################################################################################################
# ACCESS FORMATTING BASE ON THE TYPE OF USER DEVICE: MOBILE OR COMPUTER
###############################################################################################################################################################################################

try:
    with open('formatting.json', 'r') as file:
        formatting_file = json.load(file)
    
    general_formatting = formatting_file.get('general')
    
except:
    general_formatting=None
    formatting_file=None

###############################################################################################################################################################################################




###############################################################################################################################################################################################
###############################################################################################################################################################################################
# APP FUNCTION
###############################################################################################################################################################################################
def main(page: ft.Page):
    page.window.always_on_top=True
    page.bgcolor=getattr(ft.colors, general_formatting.get('page_bgcolor'))  # Color grab from Clear Safety website
    page.adaptive=True
    page.title='Clear Safety: Approval Request'
    page.horizontal_alignment=ft.CrossAxisAlignment.CENTER
    page.vertical_alignment=ft.MainAxisAlignment.START
    page.padding=ft.padding.all(0)
    



    ###########################################################################################################################################################################################
    # GLOBAL VARIABLES
    ###########################################################################################################################################################################################
    # List to store all the files uploaded into the form
    success_upload = []
    error_upload = []
    upload_directory = "assets/uploads"
    ###########################################################################################################################################################################################
    

    
    
    ###########################################################################################################################################################################################
    # INITIAL CHECKS
    ###########################################################################################################################################################################################
    # CHECK IF DATA FROM AIRTABLE HAS SUCCESSFULY BEEN RETRIEVED (EX.: SOR CODE LIST, TENURE LIST)
    def close_dialog_error_connection(e):
        dialog_error_connection.open=False
        page.update()
        page.controls.clear()
        page.add(ft.Image(src='/images/cs_logo.png', scale=0.5))
        page.update()

    dialog_error_connection = ft.AlertDialog(
        title=ft.Text(value='Clear Safety - Error'),
        content=ft.Text('Error trying to connect to the database.\nPlease check your internect connection.\nIf the problem persists, contact Clearsafety.'),
        modal=True,
        actions=[
            ft.ElevatedButton(text='Ok', on_click=close_dialog_error_connection)
        ]
        
    )
    
    if len(tenure_list) == 0 and len(sor_code_list) == 0:
        page.overlay.append(dialog_error_connection)
        dialog_error_connection.open=True
        page.update()
    #------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    # CHECK TYPE OF DEVICE USING BY THE USER AND DEFINE FORMATTING
    if formatting_file != None:
        if 'mobile' in page.client_user_agent.lower() or 'table' in page.client_user_agent.lower():
            formatting = formatting_file.get('mobile')
        else:
            formatting = formatting_file.get('computer')
    else:
        formatting = None
    #------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    ###########################################################################################################################################################################################
    
    


    ###########################################################################################################################################################################################
    # INTERNAL FUNCIONS
    ###########################################################################################################################################################################################
    # Function to add a new group of Price Breakdown or a new group of Uplip - Miscellaneous
    def add_group(e):
        if e.control.data == 'Price Breakdown':
            next_position = len(all_prices_breakdown.controls)-1
            all_prices_breakdown.controls.insert(
                -1,
                create_PriceBreakdownGroup(
                    page=page,
                    position=next_position,
                    field_textsize=formatting.get('field_text_size') if formatting != None else None,
                    field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                    field_option_source=sor_code_list_price,
                    field_column_price='SOR Cost (BSW)',
                    delete=delete_breakdown_price,
                    overal_total=overal_total
                )
            )
                
            all_prices_breakdown.update()
        
        elif e.control.data == 'Uplift':
            next_position = len(all_uplifts_miscellaneous.controls)-1
            all_uplifts_miscellaneous.controls.insert(
                -1,
                create_UpliftGroup(
                    page=page,
                    position=0,
                    field_textsize=formatting.get('field_text_size') if formatting != None else None,
                    field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                    field_option_source=sor_code_list_uplift,
                    field_column_uplift='Uplift BSW',
                    delete=delete_uplift,
                    overal_total=overal_total
                ),
            )
                
            all_uplifts_miscellaneous.update()
    #------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


    # Function to delete a group of Price Breakdown
    def delete_breakdown_price(e):
        position = e.control.data
        all_prices_breakdown.controls.pop(position)
        
        for pos, item in enumerate(all_prices_breakdown.controls[:-1]):
            item.controls[-2].data=pos        
        
        overal_total()
        
        all_prices_breakdown.update()
    #----------------------------------------------------------------------------
    

    # Function to delete a group of Uplift - Miscellaneous
    def delete_uplift(e):
        position = e.control.data
        all_uplifts_miscellaneous.controls.pop(position)
        
        for pos, item in enumerate(all_uplifts_miscellaneous.controls[:-1]):
            item.controls[-2].data=pos        
        
        overal_total()
        
        all_uplifts_miscellaneous.update()
    #----------------------------------------------------------------------------
    

    # Function to update the Overal Total and add this value to the corresponding field
    def overal_total():
        total = 0
        for item in all_prices_breakdown.controls[:-1]:
            for field in item.controls[:-2]:
                if field.label == 'Total' and field.value != '':
                    total += float(field.value.replace('£', ''))

        for item in all_uplifts_miscellaneous.controls[:-1]:
            for field in item.controls[:-2]:
                if field.label == 'Total' and field.value != '':
                    total += float(field.value.replace('£', ''))        
        
        _gran_total_value.value = f'£{total:.2f}'
        _gran_total_value.update()
    #----------------------------------------------------------------------------


    # SUBMIT FORM
    def submit_form(e):

        breakdownAnduplifts = ''
        if len(all_prices_breakdown.controls) > 1:
            for item in all_prices_breakdown.controls[:-1]:
                sor_code = item.controls[0].value
                if sor_code:
                    sor_description = item.controls[1].value
                    sor_price = item.controls[2].value
                    sor_qtd = item.controls[3].value
                    sor_total = item.controls[4].value
                    breakdownAnduplifts += f'SOR Code: {sor_code}, SOR Description: {sor_description}, Price: {sor_price}, Quantity: {sor_qtd}, Total: {sor_total}\n'
                
        
        if len(all_uplifts_miscellaneous.controls) > 1:
            breakdownAnduplifts += '\nUPLIFTS\n'
            

            for item in all_uplifts_miscellaneous.controls[:-1]:
                up_code = item.controls[0].value
                if up_code:
                    up_description = item.controls[1].value
                    up_details = item.controls[2].value
                    up_price = item.controls[3].value
                    up_percentage = item.controls[4].value
                    up_total = item.controls[5].value
                    breakdownAnduplifts += f'SOR Code: {up_code}, SOR Description: {up_description}, Details: {up_details}, Price: {up_price}, Percentage: {up_percentage}, Total: {up_total}\n'
        
        if breakdownAnduplifts == '\nUPLIFTS\n':
            breakdownAnduplifts = ''

        new_record = create_Record(
            baseID='appnACNlBdniubvWe',
            tableID='tblE5yfkwLy3HyOHC',
            content={
                'Address': address.value,
                'UPRN': uprn.value,
                'Postcode': postcode.value,
                'Tenure': tenure.value,
                'Description of work': work_description.value,
                'Price breakdown': breakdownAnduplifts,
                'Total': float(_gran_total_value.value.replace('£', '')) if _gran_total_value.value != '' else None
            }
        )

        if new_record == 'Successful':
            def close_dialog_submission_success(e):
                    dialog_submission_success.open=False
                    page.update()
                    
                    if e.control.text=='Close':
                        page.controls.clear()
                        page.add(ft.Image(src='/images/cs_logo.png', scale=0.5))
                    else:
                        address.value=''
                        uprn.value=''
                        postcode.value=''
                        tenure.value=None
                        work_description.value=''
                        all_prices_breakdown.controls=[
                            create_PriceBreakdownGroup(
                                page=page,
                                position=0,
                                field_textsize=formatting.get('field_text_size') if formatting != None else None,
                                field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                                field_option_source=sor_code_list_price,
                                field_column_price='SOR Cost (BSW)',
                                delete=delete_breakdown_price,
                                overal_total=overal_total
                            ),
                            ft.Row(
                                alignment=ft.MainAxisAlignment.END, 
                                col=3, 
                                controls=[
                                    ft.FloatingActionButton(
                                        tooltip='New SOR Code', 
                                        col=0.3, 
                                        icon=ft.icons.ADD, 
                                        mini=True, 
                                        shape=ft.CircleBorder('circle'), 
                                        bgcolor=getattr(ft.colors, general_formatting.get('field_bgcolor')),
                                        on_click=add_group,
                                        data='Price Breakdown'
                                    )
                                ]
                            ),
                        ]
                        all_uplifts_miscellaneous.controls=[
                            create_UpliftGroup(
                                page=page,
                                position=0,
                                field_textsize=formatting.get('field_text_size') if formatting != None else None,
                                field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                                field_option_source=sor_code_list_uplift,
                                field_column_uplift='Uplift BSW',
                                delete=delete_uplift,
                                overal_total=overal_total
                            ),
                            ft.Row(
                                alignment=ft.MainAxisAlignment.END, 
                                col=3, 
                                controls=[
                                    ft.FloatingActionButton(
                                        tooltip='New Uplift', 
                                        col=0.3, 
                                        icon=ft.icons.ADD, 
                                        mini=True, 
                                        shape=ft.CircleBorder('circle'), 
                                        bgcolor=getattr(ft.colors, general_formatting.get('field_bgcolor')),
                                        on_click=add_group,
                                        data='Uplift'
                                    )
                                ]
                            ),
                        ]
                        _gran_total_value.value=''
                        card_list_files.content.controls.clear()
                    page.update()

            dialog_submission_success = ft.AlertDialog(
                title=ft.Text(value='Clear Safety - Approval Request'),
                content=ft.Text('Form submitted successfully.'),
                modal=True,
                actions=[
                    ft.ElevatedButton(text='Submit another request', on_click=close_dialog_submission_success),
                    ft.ElevatedButton(text='Close', on_click=close_dialog_submission_success)
                ]
            )
            
            page.overlay.append(dialog_submission_success)
            dialog_submission_success.open=True
            page.update()


        else:
            def close_dialog_submission_error(e):
                dialog_submission_error.open=False
                page.update()
            
            dialog_submission_error = ft.AlertDialog(
                title=ft.Text(value='Clear Safety - Approval Request'),
                content=ft.Text('Error trying to submit the form. Please try again.\nIf the error persists, contact Clear Safety.'),
                modal=True,
                actions=[
                    ft.ElevatedButton(text='Ok', on_click=close_dialog_submission_error),
                ]
            )
            page.overlay.append(dialog_submission_error)
            dialog_submission_error.open=True
            page.update()

    


    #############################################################################
    # FORM
    #############################################################################

    # HEADER
    header=ft.Container(
        padding=ft.padding.symmetric(vertical=20, horizontal=40),
        bgcolor=ft.colors.GREY_100,
        content=ft.ResponsiveRow(
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                columns=2,
                controls=[
                    ft.Container(
                        col=1, 
                        alignment=ft.alignment.center_left,
                        content=ft.Image(
                            src='images/cs_logo.png', 
                            height=formatting.get('logo_header').get('height') if formatting != None else None,
                            width=formatting.get('logo_header').get('width') if formatting != None else None, 
                            col=6
                        ),
                    ),
                    
                    ft.Container(
                        col=1, 
                        alignment=ft.alignment.center_right,
                        content=ft.Column(
                            controls=[
                                ft.Text(
                                    value='Approval Request', 
                                    size=formatting.get('text_header') if formatting != None else None,
                                    color=ft.colors.GREY_700, 
                                    weight=ft.FontWeight.BOLD, 
                                    text_align=ft.TextAlign.RIGHT
                                ),
                            ],
                        )
                    ),
                ],
            )
    )
    #----------------------------------------------------------------------------
    
    # FIELDS: body of the form, where all fields are created
    form=ft.Column(
        scroll=ft.ScrollMode.ALWAYS,
        expand=True,
        width=600,
        controls=[
            ft.Container(
                padding=ft.padding.all(20),
                content=ft.ResponsiveRow(
                    columns=3,
                    controls=[
                        address := create_Textfield(
                            columns_to_occupy=3, 
                            field_textsize=formatting.get('field_text_size') if formatting != None else None,
                            field_label='Address',
                            field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                            field_hintsize=formatting.get('field_hint_size') if formatting != None else None,
                        ),

                        uprn := create_Textfield(
                            columns_to_occupy=1, 
                            field_textsize=formatting.get('field_text_size') if formatting != None else None,
                            field_label='UPRN',
                            field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                            field_hintsize=formatting.get('field_hint_size') if formatting != None else None,
                        ),

                        postcode := create_Textfield(
                            columns_to_occupy=1,
                            field_textsize=formatting.get('field_text_size') if formatting != None else None,
                            field_label='Postcode',
                            field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                            field_hintsize=formatting.get('field_hint_size') if formatting != None else None,
                        ),
                        
                        tenure := create_Dropdown(
                            columns_to_occupy=1,
                            field_label='Tenure', 
                            field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                            field_textsize=formatting.get('field_text_size') if formatting != None else None,
                            field_option_source=tenure_list,
                            field_option_text='Tenure Types',
                            field_option_tooltip='Tenure Types'
                        ),

                        work_description := create_Textfield(
                            columns_to_occupy=3, 
                            field_textsize=formatting.get('field_text_size') if formatting != None else None,
                            field_label='Description of Work', 
                            field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                            field_hintsize=formatting.get('field_hint_size') if formatting != None else None,
                            field_multiline=True, 
                            field_maxlines=5
                        ),
                        
                        ft.Divider(color="#2A685A"),
                        
                        ft.Text(
                            value='Price Breakdown',
                            size=formatting.get('title') if formatting != None else None,
                            color=ft.colors.GREY_300
                        ),
                        all_prices_breakdown := ft.ResponsiveRow(
                            col=3,
                            columns=3,
                            controls=[
                                create_PriceBreakdownGroup(
                                    page=page,
                                    position=0,
                                    field_textsize=formatting.get('field_text_size') if formatting != None else None,
                                    field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                                    field_option_source=sor_code_list_price,
                                    field_column_price='SOR Cost (BSW)',
                                    delete=delete_breakdown_price,
                                    overal_total=overal_total
                                ),
                                ft.Row(
                                    alignment=ft.MainAxisAlignment.END, 
                                    col=3, 
                                    controls=[
                                        ft.FloatingActionButton(
                                            tooltip='New SOR Code', 
                                            col=0.3, 
                                            icon=ft.icons.ADD, 
                                            mini=True, 
                                            shape=ft.CircleBorder('circle'), 
                                            bgcolor=getattr(ft.colors, general_formatting.get('field_bgcolor')),
                                            on_click=add_group,
                                            data='Price Breakdown'
                                        )
                                    ]
                                ),
                            ]
                        ),
                        
                        ft.Text(
                            value='Uplift - Miscellaneous',
                            size=formatting.get('title') if formatting != None else None,
                            color=ft.colors.GREY_300
                        ),
                        all_uplifts_miscellaneous := ft.ResponsiveRow(
                            col=3,
                            columns=3,
                            controls=[
                                create_UpliftGroup(
                                    page=page,
                                    position=0,
                                    field_textsize=formatting.get('field_text_size') if formatting != None else None,
                                    field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                                    field_option_source=sor_code_list_uplift,
                                    field_column_uplift='Uplift BSW',
                                    delete=delete_uplift,
                                    overal_total=overal_total
                                ),
                                ft.Row(
                                    alignment=ft.MainAxisAlignment.END, 
                                    col=3, 
                                    controls=[
                                        ft.FloatingActionButton(
                                            tooltip='New Uplift', 
                                            col=0.3, 
                                            icon=ft.icons.ADD, 
                                            mini=True, 
                                            shape=ft.CircleBorder('circle'), 
                                            bgcolor=getattr(ft.colors, general_formatting.get('field_bgcolor')),
                                            on_click=add_group,
                                            data='Uplift'
                                        )
                                    ]
                                ),
                            ]
                        ),
                                                
                        gran_total := ft.ResponsiveRow(
                            col=3,
                            columns=3,
                            alignment=ft.MainAxisAlignment.END,
                            vertical_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                ft.Text(
                                    value='Overal Total: ',
                                    size=formatting.get('subtitle') if formatting != None else None,
                                    color=ft.colors.GREY_300,
                                    col=2,
                                    text_align=ft.TextAlign.END
                                ),
                                _gran_total_value := create_Textfield(
                                    columns_to_occupy=1,
                                    field_value='£0.00',
                                    field_textsize=formatting.get('field_text_size') if formatting != None else None,
                                    field_label='Overal Total',
                                    field_labelsize=formatting.get('field_label_size') if formatting != None else None,
                                    field_hintsize=formatting.get('field_hint_size') if formatting != None else None,
                                    field_disable=True,
                                ),
                            ], 
                        )
                    ]
                )
            )
        ],
    )
    #----------------------------------------------------------------------------

    
    
    page.add(header, form)


ft.app(target=main, assets_dir='assets', upload_dir='assets/uploads', view=ft.AppView.WEB_BROWSER)


#SEARCH BAR https://www.youtube.com/watch?v=S0DfmuCHYGY